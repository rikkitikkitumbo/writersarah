class AllarticlesController < ApplicationController

end