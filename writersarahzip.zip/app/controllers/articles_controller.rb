class ArticlesController < ApplicationController

end