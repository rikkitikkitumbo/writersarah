class CatSerializer < ActiveModel::Serializer
  attributes :id, :title, :descript, :order_array


end
