
//= require jquery.min
//= require jquery_ujs.js
//= require bootstrap.min.js
//= require angular.min
//= require jquery-ui.min.js
//= require sugar.min
//= require xeditable.min
//= require sortable.min
//= require angular-animate.min
//= require angular-ui-router.min
//= require lodash.min
//= require restangular.min

//= require angular/edit-app.js

//= require angular/http.js.coffee
//= require angular/xeditable-options.js.coffee
//= require angular/routes.js.coffee
//= require angular/cats_controller.js.coffee

