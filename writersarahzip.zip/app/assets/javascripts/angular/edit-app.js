

WriterSarah = angular.module("WriterSarah", ["restangular", "ui.router", "xeditable", 'ui.sortable', "ngAnimate"]);
