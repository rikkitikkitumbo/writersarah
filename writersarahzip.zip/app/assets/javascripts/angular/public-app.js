

WriterSarah = angular.module("WriterSarah", ["restangular", "ui.router", "ngAnimate"]);

$(document).ready(function(){
    $('body').hide().fadeIn(1000)
});