
//= require jquery.min
//= require jquery_ujs.js
//= require bootstrap.min.js
//= require angular.min
//= require angular-animate.min
//= require angular-ui-router.min
//= require lodash.min
//= require restangular.min

//= require angular/public-app.js

//= require angular/http.js.coffee
//= require angular/routes.js.coffee
//= require angular/public_controller.js.coffee