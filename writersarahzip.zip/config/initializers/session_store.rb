# Be sure to restart your server when you modify this file.

Writersarah::Application.config.session_store :cookie_store, key: '_writersarah_session'
