class DropUsers < ActiveRecord::Migration
  def change
  end
end
