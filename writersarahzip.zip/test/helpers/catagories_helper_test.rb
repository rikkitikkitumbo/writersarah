require 'test_helper'

class CatagoriesHelperTest < ActionView::TestCase
end
