require 'test_helper'

class CatagoriesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
